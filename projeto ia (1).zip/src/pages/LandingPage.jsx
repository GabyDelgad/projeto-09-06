
import React, { useState } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Menu, X, Star, Users, BookOpen, Award, ChevronRight, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';

function LandingPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleJoinClick = () => {
    toast({
      title: "Bem-vindo ao SkillZ! 🎉",
      description: "Em breve você receberá mais informações sobre como começar sua jornada de aprendizado!",
    });
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const howItWorksSteps = [
    {
      id: 1,
      text: "Inscreva-se: Crie uma conta gratuita em poucos minutos."
    },
    {
      id: 2,
      text: "Complete Seu Perfil: Adicione informações sobre as habilidades que você pode ensinar e aquelas que gostaria de aprender."
    },
    {
      id: 3,
      text: "Explore Habilidades: Use nossa ferramenta de busca para encontrar pessoas com habilidades que você deseja adquirir."
    },
    {
      id: 4,
      text: "Conecte-se: Envie mensagens e organize sessões de troca de habilidades."
    },
    {
      id: 5,
      text: "Avalie e Seja Avaliado: Após cada troca, deixe uma avaliação para ajudar a comunidade a crescer e melhorar."
    }
  ];

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white overflow-x-hidden"
    >
      {/* Header */}
      <header className="relative z-50 px-6 py-4">
        <nav className="flex items-center justify-between max-w-7xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl font-bold gradient-text"
          >
            SkillZ
          </motion.div>
          
          <div className="hidden md:flex items-center space-x-8">
            <motion.a 
              href="#inicio" 
              className="text-gray-300 hover:text-white transition-colors duration-300"
              whileHover={{ scale: 1.05 }}
            >
              Início
            </motion.a>
            <motion.a 
              href="#features" 
              className="text-gray-300 hover:text-white transition-colors duration-300"
              whileHover={{ scale: 1.05 }}
            >
              Recursos
            </motion.a>
             <motion.a 
              href="#how-it-works" 
              className="text-gray-300 hover:text-white transition-colors duration-300"
              whileHover={{ scale: 1.05 }}
            >
              Como Funciona
            </motion.a>
            <motion.div whileHover={{ scale: 1.05 }}>
              <RouterLink 
                to="/login"
                className="text-gray-300 hover:text-white transition-colors duration-300"
              >
                Login
              </RouterLink>
            </motion.div>
          </div>

          <button 
            onClick={toggleMenu}
            className="md:hidden p-2 rounded-lg hover:bg-white/10 transition-colors"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </nav>

        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden absolute top-full left-0 right-0 bg-slate-800/95 backdrop-blur-lg border-t border-purple-500/20 px-6 py-4"
          >
            <div className="flex flex-col space-y-4">
              <a href="#inicio" className="text-gray-300 hover:text-white transition-colors" onClick={toggleMenu}>Início</a>
              <a href="#features" className="text-gray-300 hover:text-white transition-colors" onClick={toggleMenu}>Recursos</a>
              <a href="#how-it-works" className="text-gray-300 hover:text-white transition-colors" onClick={toggleMenu}>Como Funciona</a>
              <RouterLink to="/login" className="text-gray-300 hover:text-white transition-colors" onClick={toggleMenu}>Login</RouterLink>
            </div>
          </motion.div>
        )}
      </header>

      {/* Hero Section */}
      <main className="relative">
        <section id="inicio" className="max-w-7xl mx-auto px-6 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-8"
            >
              <h1 className="text-5xl lg:text-6xl font-bold leading-tight">
                Bem-vindo(a) ao{' '}
                <span className="gradient-text">SkillZ</span>
                <span className="text-purple-400">!</span>
              </h1>
              
              <p className="text-xl text-gray-300 leading-relaxed max-w-lg">
                Descubra um mundo de aprendizado e ensino colaborativo. Aqui, você pode trocar 
                suas habilidades com outras pessoas e expandir seu conhecimento de forma 
                divertida e interativa.
              </p>
              
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button 
                  onClick={handleJoinClick}
                  className="bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white px-8 py-4 text-lg rounded-full pulse-glow transition-all duration-300 group"
                >
                  Junte-se a nós!
                  <ChevronRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Button>
              </motion.div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative hidden lg:block"
            >
              <div className="grid grid-cols-3 gap-6 items-center">
                <motion.div 
                  className="floating-animation"
                  whileHover={{ scale: 1.1 }}
                >
                  <img  
                    alt="Pessoa celebrando com os braços para cima"
                    className="w-24 h-24 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 p-1"
                   src="https://images.unsplash.com/photo-1584555912641-faae18f45744" />
                </motion.div>
                <motion.div 
                  className="floating-animation"
                  whileHover={{ scale: 1.1 }}
                >
                  <img  
                    alt="Pessoa lendo um livro"
                    className="w-32 h-32 rounded-full bg-gradient-to-br from-green-500 to-blue-500 p-1"
                   src="https://images.unsplash.com/photo-1587614298171-a223667e51c2" />
                </motion.div>
                <motion.div 
                  className="floating-animation"
                  whileHover={{ scale: 1.1 }}
                >
                  <img  
                    alt="Pessoa ensinando"
                    className="w-24 h-24 rounded-full bg-gradient-to-br from-yellow-500 to-orange-500 p-1"
                   src="https://images.unsplash.com/photo-1558443957-d056622df610" />
                </motion.div>
                <motion.div 
                  className="floating-animation"
                  whileHover={{ scale: 1.1 }}
                >
                  <img  
                    alt="Pessoa enviando mensagem"
                    className="w-28 h-28 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 p-1"
                   src="https://images.unsplash.com/photo-1625708974337-fb8fe9af5711" />
                </motion.div>
                <motion.div 
                  className="floating-animation"
                  whileHover={{ scale: 1.1 }}
                >
                  <img  
                    alt="Pessoa cumprimentando"
                    className="w-24 h-24 rounded-full bg-gradient-to-br from-green-500 to-teal-500 p-1"
                   src="https://images.unsplash.com/photo-1680817162450-c34597c6d3ba" />
                </motion.div>
                <motion.div 
                  className="floating-animation"
                  whileHover={{ scale: 1.1 }}
                >
                  <img  
                    alt="Pessoa ouvindo música"
                    className="w-26 h-26 rounded-full bg-gradient-to-br from-purple-500 to-indigo-500 p-1"
                   src="https://images.unsplash.com/photo-1602788484247-5c1190ca914c" />
                </motion.div>
              </div>
              <div className="absolute -top-4 -right-4 w-20 h-20 bg-purple-500/20 rounded-full blur-xl"></div>
              <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-pink-500/20 rounded-full blur-xl"></div>
            </motion.div>
          </div>
        </section>

        {/* Features Section */}
        <motion.section 
          id="features"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="py-20 px-6 bg-slate-900/30"
        >
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-4">
                Por que escolher o <span className="gradient-text">SkillZ</span>?
              </h2>
              <p className="text-xl text-gray-300 max-w-2xl mx-auto">
                Uma plataforma completa para desenvolvimento de habilidades e conexões significativas
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <motion.div 
                whileHover={{ scale: 1.05, y: -5 }}
                className="bg-gradient-to-br from-purple-900/50 to-slate-800/50 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20"
              >
                <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center mb-4">
                  <Users className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Comunidade Ativa</h3>
                <p className="text-gray-300">Conecte-se com milhares de pessoas dispostas a compartilhar conhecimento</p>
              </motion.div>

              <motion.div 
                whileHover={{ scale: 1.05, y: -5 }}
                className="bg-gradient-to-br from-blue-900/50 to-slate-800/50 backdrop-blur-lg rounded-2xl p-6 border border-blue-500/20"
              >
                <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mb-4">
                  <BookOpen className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Aprendizado Flexível</h3>
                <p className="text-gray-300">Aprenda no seu ritmo com conteúdo adaptado às suas necessidades</p>
              </motion.div>

              <motion.div 
                whileHover={{ scale: 1.05, y: -5 }}
                className="bg-gradient-to-br from-green-900/50 to-slate-800/50 backdrop-blur-lg rounded-2xl p-6 border border-green-500/20"
              >
                <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center mb-4">
                  <Award className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Certificações</h3>
                <p className="text-gray-300">Obtenha reconhecimento pelas suas conquistas e habilidades desenvolvidas</p>
              </motion.div>

              <motion.div 
                whileHover={{ scale: 1.05, y: -5 }}
                className="bg-gradient-to-br from-yellow-900/50 to-slate-800/50 backdrop-blur-lg rounded-2xl p-6 border border-yellow-500/20"
              >
                <div className="w-12 h-12 bg-yellow-600 rounded-lg flex items-center justify-center mb-4">
                  <Star className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Qualidade Premium</h3>
                <p className="text-gray-300">Conteúdo curado por especialistas para garantir a melhor experiência</p>
              </motion.div>
            </div>
          </div>
        </motion.section>

        {/* How It Works Section */}
        <motion.section
          id="how-it-works"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
          className="py-20 px-6"
        >
          <div className="max-w-7xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
                viewport={{ once: true }}
              >
                <img  
                  alt="Ilustração de pessoas conectadas através de um dispositivo móvel, simbolizando troca de habilidades" 
                  className="w-full max-w-md mx-auto rounded-lg shadow-2xl shadow-purple-500/30"
                  src="https://images.unsplash.com/photo-1643101807331-21a4a3f081d5" />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
                viewport={{ once: true }}
                className="space-y-8"
              >
                <h2 className="text-4xl font-bold">
                  Como funciona o <span className="gradient-text">SkillZ</span>?
                </h2>
                <p className="text-xl text-gray-300">
                  Passo a Passo para Trocar Habilidades:
                </p>
                <ul className="space-y-4">
                  {howItWorksSteps.map((step, index) => (
                    <motion.li 
                      key={step.id}
                      initial={{ opacity: 0, x: 20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      viewport={{ once: true }}
                      className="flex items-start"
                    >
                      <CheckCircle className="h-6 w-6 text-purple-400 mr-3 mt-1 flex-shrink-0" />
                      <span className="text-gray-300">{step.text}</span>
                    </motion.li>
                  ))}
                </ul>
              </motion.div>
            </div>
          </div>
        </motion.section>


        {/* Background Decorations */}
        <div className="absolute top-1/4 left-10 w-2 h-2 bg-purple-400 rounded-full opacity-60 animate-pulse"></div>
        <div className="absolute top-1/3 right-20 w-3 h-3 bg-pink-400 rounded-full opacity-40 animate-pulse delay-500"></div>
        <div className="absolute bottom-1/4 left-1/4 w-1 h-1 bg-blue-400 rounded-full opacity-80 animate-pulse delay-1000"></div>
        <div className="absolute bottom-1/3 right-1/3 w-2 h-2 bg-green-400 rounded-full opacity-50 animate-pulse delay-1500"></div>
      </main>

      <footer className="py-12 px-6 bg-slate-900/50 border-t border-purple-500/20">
        <div className="max-w-7xl mx-auto text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} SkillZ. Todos os direitos reservados.</p>
          <p className="mt-2 text-sm">Construído com ❤️ e muito café!</p>
        </div>
      </footer>
    </motion.div>
  );
}

export default LandingPage;
