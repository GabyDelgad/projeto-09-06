import React, { useState } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { ArrowLeft, UserPlus } from 'lucide-react';

function RegisterPage() {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleRegister = (e) => {
    e.preventDefault();
    if (!fullName || !email || !phone || !password || !confirmPassword) {
      toast({
        title: "Erro de Registro 😕",
        description: "Por favor, preencha todos os campos.",
        variant: "destructive",
      });
      return;
    }
    if (password !== confirmPassword) {
      toast({
        title: "Erro de Senha 😕",
        description: "As senhas não coincidem.",
        variant: "destructive",
      });
      return;
    }
    // Lógica de registro aqui (ex: localStorage ou API)
    const newUser = { fullName, email, phone };
    localStorage.setItem('skillzNewUser', JSON.stringify(newUser));
    toast({
      title: "Registro bem-sucedido! 🎉",
      description: `Bem-vindo(a) ao SkillZ, ${fullName}! Seu e-mail é ${email}.`,
    });
    // Redirecionar para login ou dashboard
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white flex flex-col items-center justify-center p-4 relative overflow-hidden"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="absolute top-6 left-6"
      >
        <RouterLink to="/">
          <Button variant="ghost" className="text-gray-300 hover:text-white hover:bg-white/10">
            <ArrowLeft size={20} className="mr-2" />
            Voltar para Home
          </Button>
        </RouterLink>
      </motion.div>

      <motion.div
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 120, damping: 10, delay: 0.1 }}
        className="w-full max-w-lg bg-slate-800/70 backdrop-blur-lg p-8 rounded-2xl shadow-2xl shadow-purple-500/30 border border-purple-500/20"
      >
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold gradient-text">Criar Conta</h1>
          <p className="text-gray-400 mt-2">
            Já é um membro?{' '}
            <RouterLink to="/login" className="font-medium text-purple-400 hover:underline">
              Login
            </RouterLink>
          </p>
        </div>
        
        <div className="flex justify-center mb-8">
            <motion.div
                initial={{ scale: 0, rotate: -15 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: 'spring', stiffness: 260, damping: 20, delay: 0.3 }}
            >
                <img  
                    alt="Ilustração de uma pessoa com uma chave gigante e um cadeado, simbolizando segurança e criação de conta" 
                    className="w-48 h-auto"
                 src="https://images.unsplash.com/photo-1701898984893-94dfd9e22b89" />
            </motion.div>
        </div>


        <form onSubmit={handleRegister} className="space-y-6">
          <div>
            <Label htmlFor="fullName" className="text-gray-300 mb-2 block">Nome Completo</Label>
            <Input
              id="fullName"
              type="text"
              placeholder="Digite o seu nome completo"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="bg-slate-700/50 border-purple-500/30 focus:ring-purple-500 focus:border-purple-500"
            />
          </div>
          <div>
            <Label htmlFor="email" className="text-gray-300 mb-2 block">E-mail</Label>
            <Input
              id="email"
              type="email"
              placeholder="Digite o seu email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-slate-700/50 border-purple-500/30 focus:ring-purple-500 focus:border-purple-500"
            />
          </div>
          <div>
            <Label htmlFor="phone" className="text-gray-300 mb-2 block">Telefone</Label>
            <Input
              id="phone"
              type="tel"
              placeholder="Digite o seu telefone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="bg-slate-700/50 border-purple-500/30 focus:ring-purple-500 focus:border-purple-500"
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="password" className="text-gray-300 mb-2 block">Senha</Label>
              <Input
                id="password"
                type="password"
                placeholder="Digite sua senha"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-slate-700/50 border-purple-500/30 focus:ring-purple-500 focus:border-purple-500"
              />
            </div>
            <div>
              <Label htmlFor="confirmPassword" className="text-gray-300 mb-2 block">Confirmar Senha</Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="Confirme a senha"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="bg-slate-700/50 border-purple-500/30 focus:ring-purple-500 focus:border-purple-500"
              />
            </div>
          </div>
          <motion.div
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
          >
            <Button type="submit" className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white py-3 text-lg rounded-lg pulse-glow transition-all duration-300">
              <UserPlus size={20} className="mr-2" />
              Cadastrar
            </Button>
          </motion.div>
        </form>
      </motion.div>
      
      <div className="absolute -top-10 -left-10 w-32 h-32 bg-purple-600/20 rounded-full blur-2xl opacity-50 animate-pulse"></div>
      <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-pink-600/20 rounded-full blur-2xl opacity-50 animate-pulse delay-1000"></div>
    </motion.div>
  );
}

export default RegisterPage;