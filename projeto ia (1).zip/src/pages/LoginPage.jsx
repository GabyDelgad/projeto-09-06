
import React, { useState } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input'; 
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';

function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    if (!email || !password) {
      toast({
        title: "Erro de Login 😕",
        description: "Por favor, preencha seu e-mail e senha.",
        variant: "destructive",
      });
      return;
    }
    // Lógica de login aqui (ex: localStorage ou API)
    localStorage.setItem('skillzUserEmail', email);
    toast({
      title: "Login bem-sucedido! 🎉",
      description: `Bem-vindo(a) de volta, ${email}!`,
    });
    // Redirecionar para dashboard ou página inicial após login
    // router.push('/'); // Se usar Next.js router, ou use React Router useNavigate
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white flex flex-col items-center justify-center p-4 relative overflow-hidden"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="absolute top-6 left-6"
      >
        <RouterLink to="/">
          <Button variant="ghost" className="text-gray-300 hover:text-white hover:bg-white/10">
            <ArrowLeft size={20} className="mr-2" />
            Voltar para Home
          </Button>
        </RouterLink>
      </motion.div>

      <motion.div
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 120, damping: 10, delay: 0.1 }}
        className="w-full max-w-md bg-slate-800/70 backdrop-blur-lg p-8 rounded-2xl shadow-2xl shadow-purple-500/30 border border-purple-500/20"
      >
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold gradient-text">Login</h1>
        </div>

        <div className="flex justify-center mb-8">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 260, damping: 20, delay: 0.3 }}
          >
            <img  
              alt="Ilustração de segurança de login com um cadeado e uma chave" 
              className="w-48 h-auto"
             src="https://images.unsplash.com/photo-1654588830920-92085849e384" />
          </motion.div>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <Label htmlFor="email" className="text-gray-300 mb-2 block">E-mail</Label>
            <Input
              id="email"
              type="email"
              placeholder="seu@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-slate-700/50 border-purple-500/30 focus:ring-purple-500 focus:border-purple-500"
            />
          </div>
          <div>
            <Label htmlFor="password" className="text-gray-300 mb-2 block">Senha</Label>
            <Input
              id="password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-slate-700/50 border-purple-500/30 focus:ring-purple-500 focus:border-purple-500"
            />
          </div>
          <motion.div
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
          >
            <Button type="submit" className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white py-3 text-lg rounded-lg pulse-glow transition-all duration-300">
              Entrar
            </Button>
          </motion.div>
        </form>

        <p className="mt-8 text-center text-gray-400">
          Ainda não tem uma conta?{' '}
          <RouterLink to="/register" className="font-medium text-purple-400 hover:underline">
            Registre-se
          </RouterLink>
        </p>
      </motion.div>
      
      <div className="absolute -top-10 -left-10 w-32 h-32 bg-purple-600/20 rounded-full blur-2xl opacity-50 animate-pulse"></div>
      <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-pink-600/20 rounded-full blur-2xl opacity-50 animate-pulse delay-1000"></div>
    </motion.div>
  );
}

export default LoginPage;
